
CREATE LOGIN datacollector with PASSWORD = 'xd4578k49o';
